echo Executing NeXTTool to upload BRO_client.rxe...
 /home/ubuntu/NXT/nxtOSEK/bin/NeXTTool /COM=usb -download=BRO_client.rxe
 /home/ubuntu/NXT/nxtOSEK/bin/NeXTTool /COM=usb -listfiles=BRO_client.rxe
echo NeXTTool is terminated.
