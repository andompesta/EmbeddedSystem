#ifndef __COMMON_SETTINGS_H__
#define __COMMON_SETTINGS_H__

// Size of outgoing bluetooth buffer
#define BUFFER_SIZE 4

// Operation Types Definitions (packets type)
#define DATA_COLLECTION 1
#define WASTING_TIME 2


#endif
