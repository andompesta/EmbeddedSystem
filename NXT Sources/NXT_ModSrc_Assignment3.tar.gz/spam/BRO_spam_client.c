#include <stdio.h>
#include <math.h>
#include "headers/BRO_spam_fists.h"
#include "headers/BRO_spam_client.h"
#include "client_settings.h"
#include "../common_settings.h"
#include "ecrobot_interface.h"
#include "kernel.h"
#include "kernel_id.h"

    /*** OSEK declarations ***/

DeclareCounter(SysTimerCnt);
DeclareTask(Vehicle);
DeclareTask(Sonar);
DeclareTask(MotorA);
DeclareTask(MotorB);
DeclareTask(BRO_Comm);
DeclareTask(DisplayTask);
DeclareResource(lcd);

/*--------------------------------------------------------------------------*/

void sonar_fun ()
{
    update_timer(&sonar_timer);
    float current_measured_distance = ecrobot_get_sonar_sensor(SONAR_PORT) / 100.0; // m
    // Simulate behaviour of vehicle (NOTE: here for debugging plot reasons)
    // NOTE: theta estimate within the model is particularly BAD, better use last known angle
    oxy_rel.theta = sonar_data.cur_alpha;
    // NOTE: Every N samples force the simulation to sync to the sonar data
    if ((((int)(sonar_timer.current_time_f*1000)) / ((int)(SONAR_T*1000)) % 20) == 0)
    {
        oxy_rel.y = sonar_data.cur_estimated_distance;
    }
    // Load new Values
    sonar_data.prev_measured_distance = sonar_data.cur_measured_distance;
    sonar_data.cur_measured_distance = current_measured_distance;
    if (sonar_timer.delta_time_f > 0.0) {
        if (sonar_data.cur_measured_distance < 2.40) { // use sonar value
            // Triangulation
            float delta_space = vehicle_target_speed * sonar_timer.delta_time_f; // meters
            sonar_data.cur_error_distance = sonar_data.cur_measured_distance - sonar_data.prev_measured_distance;
            sonar_data.cur_alpha = atanf(sonar_data.cur_error_distance / delta_space); //rad
            sonar_data.cur_trigon_distance = (float) (sonar_data.cur_measured_distance * cosf(fabsf(sonar_data.cur_alpha)));
            // Prepare for Filtering
            mem_dist_sonar[mem_sonar_index] = sonar_data.cur_trigon_distance;
            mem_time_sonar[mem_sonar_index] = sonar_timer.delta_time_f;
            mem_sonar_index = (mem_sonar_index + 1) % MEM_SONAR_LENGTH;
            // Apply Filtering
            sonar_data.cur_filtered_distance = moving_average_vector(mem_dist_sonar, mem_time_sonar, MEM_SONAR_LENGTH);
            // Choose one value
            sonar_data.cur_estimated_distance = sonar_data.cur_filtered_distance;
            // Apply Unicycle Kinematic Model
            unicycle_kinematic(&sonar_timer);
        } else { // Use simulation instead of sonar
            // Last computed distance should be reliable more or less
            oxy_rel.y = sonar_data.cur_estimated_distance;
            // Apply Unicycle Kinematic to predict distance according to model
            unicycle_kinematic(&sonar_timer);
            sonar_data.cur_estimated_distance = oxy_rel.y;
            sonar_data.cur_measured_distance = oxy_rel.y; // WARNING: infinitesimal mathematics would make it unstable:
                                                          // removed: "= oxy_rel.y / cosf(sonar_data.cur_alpha);"
        }
    } else {
        sonar_data.cur_estimated_distance = current_measured_distance;
    }

    // Turbo Boost Facility
    if ((fabsf(sonar_data.cur_alpha) < 0.01)  && (fabsf(sonar_data.cur_estimated_distance - WALL_DISTANCE) < 0.035))
    {
        vehicle_target_power = 95; // %
    } else {
        vehicle_target_power = TARGET_POWER; // = 80%
    }
    vehicle_target_speed = ((k * input_power * vehicle_target_power * vehicle_wheel_radius) / 100.0);
}

//Motor function
void motor(int idMotor, motor_data* data, time_data* time)
{
    int port_motor;
    if(idMotor == 0)
    {
        port_motor = NXT_PORT_A;
    } else {
	port_motor = NXT_PORT_B;
    }

    // Get Motor Rotation Count
    data->current_rot = (float) nxt_motor_get_count(port_motor);

    // Save in Motor History rotation speed and sampling time
    mem_speed[idMotor][mem_index[idMotor]] = ((data->current_rot - data->previous_rot) / time->delta_time_f )* ( PI / 180.0 );	//rad/s
    mem_time[idMotor][mem_index[idMotor]] = time->delta_time_f;
    mem_index[idMotor] = (mem_index[idMotor] + 1) % MEM_MOTOR_LENGTH;

    // Filter speed history data to retrieve current reference speed
    data->feedback_speed = moving_average_speed(idMotor);	// rad/s

    // Compute feedback error
    float error = data->target_speed - data->feedback_speed; 	// rad/s

    controllerErrorHistory[idMotor][0] = ( 100.0/q ) * error;	// power
	// current output
    controllerOutputHistory[idMotor][0] = (Kc*((e_2*controllerErrorHistory[idMotor][2])+
        (e_1*controllerErrorHistory[idMotor][1])+(e_0*controllerErrorHistory[idMotor][0]))-
        (u_2*controllerOutputHistory[idMotor][2])-(u_1*controllerOutputHistory[idMotor][1]))/u_0;

    // Update Discrete Historical values
    controllerErrorHistory[idMotor][2] = controllerErrorHistory[idMotor][1];
    controllerErrorHistory[idMotor][1] = controllerErrorHistory[idMotor][0];
    controllerOutputHistory[idMotor][2] = controllerOutputHistory[idMotor][1];
    controllerOutputHistory[idMotor][1] = controllerOutputHistory[idMotor][0];

    // Apply Saturation
    if (controllerOutputHistory[idMotor][0] > 100)
        controllerOutputHistory[idMotor][0] = 100.0;
    if (controllerOutputHistory[idMotor][0] < -100)
        controllerOutputHistory[idMotor][0] = -100.0;

    // Update data structure
    data->out_power = controllerOutputHistory[idMotor][0];
    data->previous_rot = data->current_rot;

    // NOTE: No antiwindup here since we had a couple of complex and conjugated zeros in our engine controller and
    //       it would not work on the discretized real brick. And no Smith Predictor too: the idea is fancy but it
    //       is not worth the trouble implement it. So we cheated a bit in respect to Anti WindUp and Smith Predictor.
    //       Oh yes, the cake is a lie too. The Game.
}

/*--------------------------------------------------------------------------*/

    /*** TASKS ***/

TASK(BRO_Comm)
{
    time_data* time = &bt_timer;
    update_timer(time);

    // Set Outgoing packet
    out_packet_buffer[out_packet_buffer_index].operation = DATA_COLLECTION;
    out_packet_buffer[out_packet_buffer_index].port = 0;
    out_packet_buffer[out_packet_buffer_index].time = time->current_time_f;
    out_packet_buffer[out_packet_buffer_index].target_powerA = sonar_data.cur_measured_distance;
    out_packet_buffer[out_packet_buffer_index].feedback_powerA = sonar_data.cur_trigon_distance;
    out_packet_buffer[out_packet_buffer_index].target_powerB = sonar_data.cur_filtered_distance;
    out_packet_buffer[out_packet_buffer_index].feedback_powerB = oxy_rel.y;

    ++out_packet_buffer_index;

    // Send the Packet if the Buffer is Full
    if (out_packet_buffer_index == BUFFER_SIZE) {
        // Send Data only if it has a meaning to do so;
        bt_send((U8*) out_packet_buffer, sizeof(bro_fist_t) * BUFFER_SIZE);
        out_packet_buffer_index = 0;
        memset (out_packet_buffer, 0, sizeof(bro_fist_t) * BUFFER_SIZE);
    }

    // Set LCD content (just some random data)
    // WARNING: when you enable this code, comment the first line in DISPLAY_TASK
    display_clear(0);
    int temp = (int) (sonar_data.cur_measured_distance * 100);
    display_goto_xy(0,0);
    display_string("Time:");
    display_goto_xy(0,1);
    display_int(temp, 0);
    display_goto_xy(0,2);
    display_string("uk_b:");
    display_goto_xy(0,3);
    //display_int((int)dataA.feedback_speed, 0);
    display_int((int) dataA.target_speed, 0);
    display_goto_xy(0,4);
    display_string("uk_c:");
    display_goto_xy(0,5);
    //display_int((int) dataA.target_speed, 0);
    display_int((int) dataA.out_power, 0);
    display_update();

    TerminateTask();
}

TASK(Vehicle)
{
    motor_data* dataMotorA = &dataA;
    motor_data* dataMotorB = &dataB;

    // Compute Feedback Distance Error
    controllerVehicleErrorHistory[0] = sonar_data.target_distance - sonar_data.cur_estimated_distance;

    // current output
    controllerVehicleOutputHistory[0] = (vKc*((ve_2*controllerVehicleErrorHistory[2])+
        (ve_1*controllerVehicleErrorHistory[1])+(ve_0*controllerVehicleErrorHistory[0]))-
        (vu_2*controllerVehicleOutputHistory[2])-(vu_1*controllerVehicleOutputHistory[1]))/vu_0;
    // Update Discrete Historical values
    controllerVehicleErrorHistory[2] = controllerVehicleErrorHistory[1];
    controllerVehicleErrorHistory[1] = controllerVehicleErrorHistory[0];
    controllerVehicleOutputHistory[2] = controllerVehicleOutputHistory[1];
    controllerVehicleOutputHistory[1] = controllerVehicleOutputHistory[0];

    // Apply Saturation
#ifdef SATURATION
    if(controllerVehicleOutputHistory[0] > SAT_LEVEL )
    {
        controllerVehicleOutputHistory[0] = SAT_LEVEL;
    }
    if(controllerVehicleOutputHistory[0] < -SAT_LEVEL)
    {
       	controllerVehicleOutputHistory[0] = -SAT_LEVEL;
    }
#endif
    omega = controllerVehicleOutputHistory[0];

    float target_speed_left = (2.0*vehicle_target_speed - vehicle_rod_length*omega)/(2.0*vehicle_wheel_radius);	//rad/s
    float target_speed_right = (2.0*vehicle_target_speed + vehicle_rod_length*omega)/(2.0*vehicle_wheel_radius); //rad/s

    dataMotorA->target_speed = target_speed_left; //rad/s
    dataMotorB->target_speed = target_speed_right; //rad/S

    TerminateTask();
}

TASK(MotorA)
{
    motor_data* data = &dataA;
    time_data* time = &timeA;
    update_timer(&timeA);
    motor(Motor_A, data, time);
    nxt_motor_set_speed( NXT_PORT_A, data->out_power, BRAKE_SETTING);
    TerminateTask();
}

TASK(MotorB)
{

    motor_data* data = &dataB;
    time_data* time = &timeB;
    update_timer(time);
    motor(Motor_B, data, time);
    nxt_motor_set_speed( NXT_PORT_B, data->out_power, BRAKE_SETTING);
    TerminateTask();
}

TASK(Sonar)
{
    sonar_fun();
    TerminateTask();
}

TASK(DisplayTask)
{
//    ecrobot_status_monitor("BROFist Client");
    TerminateTask();
}

/*--------------------------------------------------------------------------*/

    /*** Less Interesting Help Functions ***/

// NOTE: this function assumes that the LEFT motor is attached to port A
//       and RIGHT motor is attached to port B
void unicycle_kinematic(time_data* time)
{
    if ((time->current_time_f - time->start_time_f) < (SONAR_T*2.1)) {
        // At the beginning just use the data coming from the sonar
        oxy_rel.y = sonar_data.cur_estimated_distance;
        oxy_rel.theta = sonar_data.cur_alpha;
    } else {
        // Compute Current Vehicle Speed and Angular Speed
        oxy_rel.vehicle_forward_speed = (vehicle_wheel_radius / 2.0) * (dataA.feedback_speed + dataB.feedback_speed);
        oxy_rel.vehicle_angular_speed = (vehicle_wheel_radius / vehicle_rod_length) * (dataB.feedback_speed - dataA.feedback_speed);
        // Compute new position vector
        oxy_rel.x = oxy_rel.x + (cosf(oxy_rel.theta) * oxy_rel.vehicle_forward_speed * time->delta_time_f);
        oxy_rel.y = oxy_rel.y + (sinf(oxy_rel.theta) * oxy_rel.vehicle_forward_speed * time->delta_time_f);
        oxy_rel.theta = (oxy_rel.vehicle_angular_speed * time->delta_time_f);
    }
}

void update_timer(time_data* time)
{
    // Save last timer activation time
    float last_time_f = time->current_time_f;
    // Compute new Values
    float current_time_f = ((float) systick_get_ms()) / 1000.0;
    if (time->start_time_f < 0.0)
    {
        time->start_time_f = current_time_f;
        time->current_time_f = 0.0;
        time->delta_time_f = 0.0;
    } else {
        time->current_time_f = current_time_f - time->start_time_f;
        time->delta_time_f = time->current_time_f - last_time_f;
    }
}

float moving_average_vector(float* data, float* time, int size)
{
    float acc_data_f = 0.0;
    float acc_time_f = 0.0;
    for (int i = 0; i < size; ++i)
    {
        acc_data_f += data[i]*time[i];
        acc_time_f += time[i];
    }
    if (acc_time_f > 0.0)
        acc_data_f /= acc_time_f;
    return acc_data_f;
}

float moving_average_speed(int idMotor)
{
    return moving_average_vector(mem_speed[idMotor], mem_time[idMotor], MEM_MOTOR_LENGTH);
}

/*--------------------------------------------------------------------------*/
/* LEJOS OSEK hooks                                                         */
/*--------------------------------------------------------------------------*/
void ecrobot_device_initialize()
{
    ecrobot_init_bt_slave("1234");

    memset(&engines, 0, sizeof(engines_t));

    engines.first.port = NXT_PORT_A;
    engines.first.speed_control_type = NOT_USING;
    engines.first.speed_ref = 0;

    engines.second.port = NXT_PORT_B;
    engines.second.speed_control_type = NOT_USING;
    engines.second.speed_ref = 0;

    engines.third.port = NXT_PORT_C;
    engines.third.speed_control_type = NOT_USING;
    engines.third.speed_ref = 0;

    // Reset Memory
    memset (out_packet_buffer, 0, sizeof(bro_fist_t) * BUFFER_SIZE);

    memset (mem_speed, 0, sizeof(float) * (MEM_MOTOR_LENGTH * 2));
    memset (mem_time,  0, sizeof(float) * (MEM_MOTOR_LENGTH * 2));
    memset (mem_index,  0, sizeof(float) * 2);
    // Reset Controller
    memset (controllerOutputHistory, 0, sizeof(float) * 6 );
    memset (controllerErrorHistory, 0, sizeof(float) * 6 );

    ecrobot_init_sonar_sensor(SONAR_PORT);

    vehicle_target_speed = ((k * input_power * vehicle_target_power * vehicle_wheel_radius) / 100.0);

    // FIXME: temporary trial
    // Reset Timers at the very beginning so they're synch
    update_timer(&timeA);
    update_timer(&timeB);
    update_timer(&sonar_timer);
    update_timer(&bt_timer);

    if (CONN_LIGHT) {
        ecrobot_set_light_sensor_active(LIGHT_PORT);
    };
}


void ecrobot_device_terminate()
{

    memset(&engines, 0, sizeof(engines_t));

    nxt_motor_set_speed(NXT_PORT_A, 0, 1);
    nxt_motor_set_speed(NXT_PORT_B, 0, 1);
    nxt_motor_set_speed(NXT_PORT_C, 0, 1);

    ecrobot_set_light_sensor_inactive(LIGHT_PORT);
    ecrobot_term_sonar_sensor(SONAR_PORT);

    bt_reset();

    ecrobot_term_bt_connection();
}

void user_1ms_isr_type2(void)
{
    StatusType ercd;

    /*
     *  Increment OSEK Alarm System Timer Count
    */
    ercd = SignalCounter( SysTimerCnt );
    if ( ercd != E_OK ) {
        ShutdownOS( ercd );
    }
}

/*--------------------------------------------------------------------------*/
