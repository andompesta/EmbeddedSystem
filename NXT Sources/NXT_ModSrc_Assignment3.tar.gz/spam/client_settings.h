#ifndef __CLIENT_SETTINGS_H__
#define __CLIENT_SETTINGS_H__

/**
 * NOTE: edit this file to impose your own settings
 */

/*--------------------------------------------------------------------------*/
    // Generic Definitions

// Target Motor
enum motor_id {Motor_A, Motor_B, Motor_C};
// SINUSOID: settings
#define PI (3.14159265359)
// Should be always 1 `ON' (other valid value: 0 `OFF')
#define BRAKE_SETTING 1
// OPERATION TYPES DEFINITIONS (packets type)
//#define DATA_COLLECTION 1
//#define WASTING_TIME 2
// NOTE: defined in ../common_settings.h

    // Operating Conditions

// Size of outgoing bluetooth buffer
//#define BUFFER_SIZE 4
// NOTE: defined in ../common_settings.h
// Sonar timer
// WARNING: if you change it, you should update also BRO_spam_client.oil file!
#define SONAR_T (0.050)
// Size Average Window for Motor Speed
#define MEM_MOTOR_LENGTH 5
// Size Average Window for Sonar Distance
#define MEM_SONAR_LENGTH 5
// Distance from wall
#define WALL_DISTANCE (0.5)
// Target Power
#define TARGET_POWER 80 // WARNING: it is mandatorily defined by the chosen vehicle root locus!

    // Vehicle Configuration and Global Variables

// Vehicle 
const float vehicle_rod_length = 0.094; // meters
const float vehicle_wheel_radius = 0.028; // meters

// Some global definitions used throughout the source code
float vehicle_target_power = TARGET_POWER;
float vehicle_target_speed = 0.0;
float omega = 0.0;

/*--------------------------------------------------------------------------*/
    // Controllers Settings

// >> LEGO NXT Motor System
#define k (2.033620)
#define csi (0.730782)
#define omega_n (20.907025)
#define q (15.048788)
#define input_power (7.4)

// Wheel Controller Coefficients
// The underscore stands for "minus", e: error, u: controller output
#define e_2 (0.7453594)   // Order 0 Numerator C(z)
#define e_1 (-1.6592812)  // Order 1 Numerator C(z)
#define e_0 (0.9286927)   // Order 2 Numerator C(z)
#define u_2 (0.6666667)   // Order 0 Denominator C(z)
#define u_1 (- 1.6666667) // Order 1 Denominator C(z)
#define u_0 (1.0)         // Order 2 Denominator C(z)
#define Kc (3.5)

// Vehicle Controller Coefficients
// The underscore stands for "minus", e: error, u: controller output
// 100 ms, GOOD, suited for target power 80
#define ve_2 (0.0)        // Absent in our controller
#define ve_1 (-0.8637363) // Order 0 Numerator C(z)
#define ve_0 (0.8945055)  // Order 1 Numerator C(z)
#define vu_2 (0.0)        // Absent in our controller
#define vu_1 (-0.7582418) // Order 0 Denominator C(z)
#define vu_0 (1.0)        // Order 1 Denominator C(z)
#define vKc (9)         // NOTE: originally was 10, 9 is a bit more aggresive and still works

    // Additional Features

// WARNING: if you end up using saturation it means that you have done something
// wrong with the Root Locus analysis. Using saturation over the Vehicle Controller
// withouth an appropriate Anti WindUp system will inevitably degrade performances!
#define SATURATION 1
#define SAT_LEVEL (0.5)
#undef SATURATION // NOTE: comment to use saturation

/*--------------------------------------------------------------------------*/

    /*** DATA STRUCTURES ***/

typedef struct m_data {
    float current_rot;
    float previous_rot;
    float feedback_speed;
    float target_speed;
    float out_power;
} motor_data;

typedef struct time_data {
    float current_time_f;
    float delta_time_f;
    float start_time_f;
} time_data;

typedef struct v_pos {
    float x; // m
    float y; // m
    float theta; // rad
    float vehicle_forward_speed; // rad/s
    float vehicle_angular_speed; // rad/s
} v_pos;

typedef struct s_data{
    float target_distance; // All in meters
    float cur_measured_distance;
    float prev_measured_distance;
    float cur_estimated_distance;
    float cur_filtered_distance;
    float cur_trigon_distance;
    float cur_alpha;
    float cur_error_distance;
} s_data;

/*--------------------------------------------------------------------------*/

    /*** GLOBAL VARIABLES ***/

engines_t engines;
// OUT PACKET BUFFER
bro_fist_t out_packet_buffer[BUFFER_SIZE];
int out_packet_buffer_index = 0;
// Controllers History
float controllerVehicleOutputHistory[3]; // Vehicle Controller Output History
float controllerVehicleErrorHistory[3];  // Vehicle Controller Error History
float controllerOutputHistory[2][3];	 // Motors Controller Output History
float controllerErrorHistory[2][3];	 // Motors Controller Error History
// Motor Speed History (Filtering)
float mem_speed[3][MEM_MOTOR_LENGTH];
float mem_time[3][MEM_MOTOR_LENGTH];
unsigned int mem_index[2];
// Sonar Distance History (Filtering)
float mem_dist_sonar[MEM_SONAR_LENGTH];
float mem_time_sonar[MEM_SONAR_LENGTH];
unsigned int mem_sonar_index;
// Motor A (LEFT MOTOR!)
time_data timeA = {-1, 0.0, 0.0};
motor_data dataA;
// motor B (RIGHT MOTOR!)
time_data timeB = {-1, 0.0, 0.0};
motor_data dataB;
// Sonar Data & Time
time_data sonar_timer = {0.0, 0.0, 0.0};
// WARNING: better leave all data initialized to WALL_DISTANCE to avoid initial error!
s_data sonar_data = {WALL_DISTANCE, WALL_DISTANCE, WALL_DISTANCE, WALL_DISTANCE, WALL_DISTANCE, WALL_DISTANCE, 0.0, 0.0 };
// Bluetooth Timer
time_data bt_timer = {-1, 0.0, 0.0};
// Vehicle Coordinates
v_pos oxy_rel = {0.0, 0.0, 0.0, 0.0, 0.0};


/*--------------------------------------------------------------------------*/

    /*** Function Declarations ***/

void update_timer(time_data* time);
void unicycle_kinematic(time_data* time);
float moving_average_vector(float* data, float* time, int size);
float moving_average_speed(int idMotor);
void motor(int idMotor, motor_data* data, time_data* time);
void sonar_fun();

#endif
